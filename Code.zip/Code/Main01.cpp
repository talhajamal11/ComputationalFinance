#include <iostream>
using namespace std;

int main()
{
   //display message
   cout << "Hi there" << endl;

   //pause program
   char x; cin >> x;

   return 0;
}
